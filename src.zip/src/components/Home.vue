<template>
  <div>
    <h1>Welcome to the Home Page</h1>
    <p>You have successfully logged in!</p>

    <div>
      <label for="friendName">Enter Friend's Name:</label>
      <input type="text" v-model="friendName" required />
      <button @click="findFriend">Find Friend</button>
    </div>
    <div v-if="friendResult">
      <p>Friend found: {{ friendResult.username }}</p>
      <button @click="sendFriendRequest(friendResult.id)">
        Send Friend Request
      </button>
    </div>

    <div>
      <h2>Your Friends</h2>
      <select>
        <option v-for="friend in friends" :key="friend.id" :value="friend.id">
          {{ friend.username }}
        </option>
      </select>
    </div>

    <button @click="logout">Logout</button>
  </div>
</template>
  
  <script setup>
import axios from "axios";
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";

const token = localStorage.getItem("token");
const userId = localStorage.getItem("userId");
const router = useRouter();
const friendName = ref("");
const friendResult = ref(null);
const friends = ref([]);

const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("userId");
  router.push({ name: "login" });
};

const findFriend = () => {
  if (!friendName.value) {
    alert("Please enter a friend's name");
    return;
  }

  axios
    .get("http://localhost:3000/findFriend", {
      params: { name: friendName.value },
      headers: { Authorization: token },
    })
    .then((response) => {
      friendResult.value = response.data.friend;
    })
    .catch((error) => {
      console.error("Error finding friend:", error);
      alert("Error finding friend");
    });
};

const sendFriendRequest = (receiverId) => {
  axios
    .post(
      "http://localhost:3000/sendFriendRequest",
      {
        senderId: userId,
        receiverId,
      },
      {
        headers: { Authorization: token },
      }
    )
    .then(() => {
      alert("Friend request sent successfully");
    })
    .catch((error) => {
      console.error("Error sending friend request:", error);
    });
};

const fetchFriends = () => {
  axios
    .get("http://localhost:3000/friends", {
      params: { userId },
      headers: { Authorization: token },
    })
    .then((response) => {
      friends.value = response.data.friends;
    })
    .catch((error) => {
      console.error("Error fetching friends:", error);
    });
};

onMounted(() => {
  if (!token) {
    router.push({ name: "login" });
  } else {
    fetchFriends();
  }
});
</script>
  